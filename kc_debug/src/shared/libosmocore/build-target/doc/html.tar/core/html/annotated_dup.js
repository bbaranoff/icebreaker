var annotated_dup =
[
    [ "osmo_crc16gen_code", "structosmo__crc16gen__code.html", "structosmo__crc16gen__code" ],
    [ "osmo_crc32gen_code", "structosmo__crc32gen__code.html", "structosmo__crc32gen__code" ],
    [ "osmo_crc64gen_code", "structosmo__crc64gen__code.html", "structosmo__crc64gen__code" ],
    [ "osmo_crc8gen_code", "structosmo__crc8gen__code.html", "structosmo__crc8gen__code" ]
];