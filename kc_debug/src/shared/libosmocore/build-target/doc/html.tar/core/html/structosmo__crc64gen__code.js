var structosmo__crc64gen__code =
[
    [ "bits", "structosmo__crc64gen__code.html#a564630c90a1088175bb62126f7c9b0c3", null ],
    [ "init", "structosmo__crc64gen__code.html#a73757c2782b9d2e48a64a7d53ea605c3", null ],
    [ "poly", "structosmo__crc64gen__code.html#abef85ea259654d573330a1fad0b7f969", null ],
    [ "remainder", "structosmo__crc64gen__code.html#a432d6a569fd5d86bb80a7f6fe9c954e4", null ]
];